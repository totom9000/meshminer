@echo off
title MeshPool Miner - GPU self-test
cd /d "%~dp0"
meshpool-miner.exe --verify
echo.
pause
