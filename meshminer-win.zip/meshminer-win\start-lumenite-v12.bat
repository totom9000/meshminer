@echo off
title MeshPool Miner - Lumenite (HomeScrypt v1.2)
REM  Work from this file's own folder, so the .exe is found no matter
REM  what directory the shortcut or right-click menu started us in.
cd /d "%~dp0"
REM ===================================================================
REM  MeshPool - Lumenite (HomeScrypt v1.2)  --  MAINNET
REM ===================================================================

set POOL=pool.meshpool.net:3335
set WALLET=PUT_YOUR_LUMENITE_ADDRESS_HERE
set WORKER=rig1
set BACKEND=cuda

REM ===================================================================

if "%WALLET%"=="PUT_YOUR_LUMENITE_ADDRESS_HERE" (
  echo.
  echo   Open this file in Notepad and set WALLET to your own lmt1 address first.
  echo.
  pause
  exit /b 1
)

meshpool-miner.exe --pool %POOL% --user %WALLET%.%WORKER% --backend %BACKEND% --algo v12

echo.
echo   The miner stopped. Scroll up for the reason.
pause
