#!/usr/bin/env sh
# MeshPool miner, Lumenite HomeScrypt v1.2  --  MAINNET.
#
# Set WALLET to your own lmt1 address, then: ./start-lumenite-v12.sh

POOL=pool.meshpool.net:3335
WALLET=PUT_YOUR_LUMENITE_ADDRESS_HERE
WORKER=rig1
BACKEND=cuda          # cuda, cpu, or both

if [ "$WALLET" = "PUT_YOUR_LUMENITE_ADDRESS_HERE" ]; then
  echo
  echo "  Open this file in an editor and set WALLET to your own lmt1 address first."
  echo
  exit 1
fi

cd "$(dirname "$0")" || exit 1
exec ./meshpool-miner --pool "$POOL" --user "$WALLET.$WORKER" --backend "$BACKEND" --algo v12
