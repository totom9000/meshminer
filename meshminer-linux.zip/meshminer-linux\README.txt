MeshPool Miner
===========================

A miner for Lumenite (HomeScrypt) on MeshPool. Mines on your NVIDIA GPU,
your processor, or both at once.


QUICK START
-----------

1. Right-click start-lumenite.bat -> Edit, and replace
   PUT_YOUR_LUMENITE_ADDRESS_HERE with your own wallet address.

2. Save, close, and double-click start-lumenite.bat.

That is all. There is nothing to install and no config file.


WHAT IS IN HERE
---------------

  ./meshpool-miner        the miner
  start-lumenite-v12.sh    start mining on the v1.2 test chain
  ./gpu-validate             verify your GPU computes correct hashes


REQUIREMENTS
------------

  GPU mining   NVIDIA card, RTX 20-series or newer (Turing or later),
               with a current NVIDIA driver. No CUDA toolkit needed —
               the driver is enough, and the kernel is built into the
               .exe rather than shipped beside it.

               GTX 10-series and older will not work.

  CPU mining   Any 64-bit machine. Slower, but it works everywhere.

  Linux        Any x86-64 distribution with glibc 2.31 or newer
               (Ubuntu 20.04, Debian 11, and anything later). The binary
               needs only libc and libgcc; the NVIDIA driver is loaded at
               run time, so no CUDA toolkit is required.


OPTIONS
-------

Edit the variables at the top of the .bat file:

  BACKEND=both     GPU and processor together
  BACKEND=cuda     GPU only
  BACKEND=cpu      processor only

  WORKER=rig1      names this machine, so you can tell your machines
                   apart on the pool page

You can also run it directly if you prefer a terminal:

  ./meshpool-miner --pool pool.meshpool.net:3335 ^
                     --user YOUR_ADDRESS.rig1 --backend both

  ./meshpool-miner --help    for everything else


MATCHING THE CHAIN — READ THIS
------------------------------

Two things in this miner have to match the chain you point it at, and
getting either wrong fails silently: the miner hashes perfectly at full
speed, reports a healthy hashrate, and finds nothing, forever. There is
no error message and nothing looks wrong.

  The algorithm    v1.1 and v1.2 are different proof-of-work functions.
                   Set with --algo. The .bat files set it for you.

  The FP pass count  v1.2 only. It changes the digest without changing
                   anything you can see. A build made for a different
                   count is as useless as the wrong algorithm.

Both are printed at startup, before mining begins:

  Algorithm:  52c677ceab4a (modified), v1.2 fp 6 passes, kernel 5a9052e7096f

Check that line against what the pool operator told you to expect. If the
pass count differs, you need a different build — no setting will fix it.

IF SOMETHING IS WRONG
---------------------

Run ./gpu-validate first. It hashes on your GPU and on your processor and
compares the results (the same check as ./meshpool-miner --verify), which is the one check that tells a real problem
from a slow one. It needs no pool, no wallet and no network. If it says
the kernels agree, your GPU is computing correctly and the problem is
somewhere else.

Cannot connect / connection refused
  The pool's stratum port may not be reachable yet. Check with whoever
  gave you this build.

Your antivirus quarantines the file
  Mining software is flagged constantly, by every vendor, because the
  same programs get installed by people who should not be installing
  them. The script you launch is plain text you can read first. Add an
  exclusion for this folder to run it.

Permission denied
  chmod +x meshpool-miner start-lumenite-v12.sh
