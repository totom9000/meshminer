#!/usr/bin/env sh
cd "$(dirname "$0")" || exit 1
./meshpool-miner --verify
